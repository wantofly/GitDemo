In this location program will generate 5 files: 
- training.txt (Contain training data set)
- test.txt (Contain test data set )
- balanceTraining.txt (Contain balanced training data set)
- normalizedBalanceTraining.txt (Contain normalized balanced training data set) 
- trainedNetwork.txt (Contain trained Neural network)

This files will be generated (updated) every time when you run the program. 